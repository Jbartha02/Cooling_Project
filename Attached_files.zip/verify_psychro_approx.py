"""
Validates the psychrometric linearisation used in config.py.

The simulation avoids expensive CoolProp calls during time integration by
approximating h*(T, X) with a bilinear polynomial:

    h*(T, X)  ≈  CP_A * T  +  H_A0  +  X * (L0 + CP_W * T)    [kJ/kg_dry]

Calibration: two support points (T = 5 °C and T = 20 °C) at X = 0 and
X = 0.002 kg/kg. Coefficients are computed once at import time in config.py.

The inverse — recovering T from the ODE state (h*, X) — is algebraic:

    T(h*, X)  =  (h* - H_A0 - X * L0) / (CP_A + X * CP_W)      [°C]

This script quantifies the error of both directions against CoolProp on a
dense grid spanning the realistic server-room operating range.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import numpy as np
import Fluid_CP_moist_air as Fmoist
import clean_code.config as cfg

# ── Test grid ─────────────────────────────────────────────────────────────────
# Operating range: T from 1 to 35 °C (room + outdoor), X 0.001..0.018 kg/kg
T_grid = np.linspace(1., 35., 69)          # 0.5 K steps (starting at 1 °C to avoid freezing)
X_grid = np.array([0.001, 0.003, 0.005, 0.008, 0.010, 0.013, 0.015, 0.018])

# ── Print coefficients ────────────────────────────────────────────────────────
print("Linearisation coefficients (calibrated at T = 5 °C and 20 °C):")
print(f"  CP_A = {cfg._CP_A:.5f}  kJ/(kg_dry . K)    specific heat of dry air")
print(f"  H_A0 = {cfg._H_A0:.5f}  kJ/kg_dry           reference enthalpy offset (dry air)")
print(f"  CP_W = {cfg._CP_W:.5f}  kJ/(kg_dry . K)    dh*/dT per kg/kg moisture")
print(f"  L0   = {cfg._L0:.5f}  kJ/kg_dry           latent heat reference at 0 °C")
print()

# ── Error calculation ─────────────────────────────────────────────────────────
err_h = []   # h*_approx - h*_CoolProp  [kJ/kg]
err_T = []   # T_approx(h*_CP, X) - T_true  [K]
points = []  # (T, X) for worst-case output

skipped = 0
for T in T_grid:
    for X in X_grid:
        try:
            # CoolProp reference (may fail for oversaturated states)
            h_cp = Fmoist.state_moist(["T", "X"], [T, X])["h*"]
        except Exception:
            skipped += 1
            continue

        # Forward: analytical → CoolProp
        h_approx = cfg._CP_A * T + cfg._H_A0 + X * (cfg._L0 + cfg._CP_W * T)
        err_h.append(h_approx - h_cp)

        # Inverse: T recovered from CoolProp h* analytically
        T_approx = (h_cp - cfg._H_A0 - X * cfg._L0) / (cfg._CP_A + X * cfg._CP_W)
        err_T.append(T_approx - T)

        points.append((T, X))

if skipped:
    print(f"(Skipped: {skipped} oversaturated points)\n")

err_h  = np.array(err_h)
err_T  = np.array(err_T)
points = np.array(points)

# ── Results ───────────────────────────────────────────────────────────────────
print(f"Test grid: {len(T_grid)} T-values x {len(X_grid)} X-values = {len(err_h)} points")
print(f"T range: {T_grid[0]:.0f} ... {T_grid[-1]:.0f} °C")
print(f"X range: {X_grid[0]:.3f} ... {X_grid[-1]:.3f} kg/kg")
print()

print("Error  h*(T,X):  analytical - CoolProp  [kJ/kg_dry]")
print(f"  Max. |error|  : {np.max(np.abs(err_h)):.5f} kJ/kg")
print(f"  Mean |error|  : {np.mean(np.abs(err_h)):.5f} kJ/kg")
print(f"  Std. dev.     : {np.std(err_h):.5f} kJ/kg")

idx_h = np.argmax(np.abs(err_h))
Tw, Xw = points[idx_h]
print(f"  Worst case: T = {Tw:.1f} °C, X = {Xw:.3f} kg/kg, "
      f"error = {err_h[idx_h]:+.5f} kJ/kg")
print()

print("Error  T(h*, X): analytical inversion - CoolProp  [K]")
print(f"  Max. |error|  : {np.max(np.abs(err_T)):.5f} K")
print(f"  Mean |error|  : {np.mean(np.abs(err_T)):.5f} K")
print(f"  Std. dev.     : {np.std(err_T):.5f} K")

idx_T = np.argmax(np.abs(err_T))
Tw2, Xw2 = points[idx_T]
print(f"  Worst case: T = {Tw2:.1f} °C, X = {Xw2:.3f} kg/kg, "
      f"error = {err_T[idx_T]:+.5f} K")
print()

# ── Context: typical h* change per timestep ───────────────────────────────────
# Room at 15 °C, q_server = 5 kW, dt = 300 s, m_air ~ 257 kg
dh_step = 5.0 * 300.0 / 257.0  # kJ/kg, corresponds to ~5.8 K
T_step  = dh_step / cfg._CP_A
print(f"For context: typical h* change per timestep ({dh_step:.2f} kJ/kg"
      f" ≈ {T_step:.2f} K)")
print(f"-> Linearisation error in h* ({np.max(np.abs(err_h)):.4f} kJ/kg) is"
      f" {100*np.max(np.abs(err_h))/dh_step:.2f}% of one timestep")
print(f"-> Temperature error ({np.max(np.abs(err_T)):.4f} K) << thermostat hysteresis (5 K)")
