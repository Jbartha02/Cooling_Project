# Server Room Cooling — Simulation Code
**SHCT SS2026 Student Project — Bartha & Kellenberger**

## Quick Start

Precomputed performance maps and simulation results are already included.
To reproduce the plots and ranking, simply run:

```
python clean_code/main.py
```

No recomputation needed. Set `build_map=True` or `sweep=True` in the `TESTS`
list at the top of `main.py` only if you want to recompute from scratch
(map build: ~2 min).

## Requirements

```
pip install CoolProp numpy scipy pandas matplotlib
```

## File structure

```
├── Fluid_CP.py                   CoolProp wrapper for pure refrigerants (Roskosch)
├── Fluid_CP_moist_air.py         CoolProp wrapper for moist air (Roskosch)
├── compressor_model.py           Reciprocating compressor: volumetric & isentropic efficiency
├── verify_psychro_approx.py      Validates the bilinear h*(T,X) approximation vs CoolProp
│
├── ac_model/
│   ├── config.py                 AC-model parameters (refrigerant, compressor, pinch)
│   └── ac.py                     Refrigerant cycle states + NLP COP optimisation
│
└── clean_code/
    ├── config.py                 Central parameter file (all settings in one place)
    ├── performance_map.py        Build and query the precomputed COP/Q lookup tables
    ├── simulation.py             5-min on/off thermostat simulation (room ODE)
    ├── energy.py                 Daily energy balance and annual extrapolation
    ├── main.py                   Entry point: full sweep over all 9 configurations
    ├── selection.py              Compare multiple result folders, generate comparison plot
    ├── maps/                     Precomputed performance maps (.pkl) — loaded by default
    └── results_5C_sh5_pev5_pco10_fan153/
                                  Precomputed simulation CSVs + ranking — loaded by default
```

## How to run

### Option A — Use precomputed data (default, instant)
```
python clean_code/main.py
```
Loads maps and results from the included folders, generates plots for the
top configurations, and prints the ranking table.

### Option B — Recompute everything from scratch
Edit the `TESTS` list in `clean_code/main.py`:
```python
"build_map": True,   # rebuilds performance maps (~2 min)
"sweep":     True,   # reruns all 9 × 4-season simulations
```
Then run `python clean_code/main.py`.

### Validate the psychrometric approximation
```
python verify_psychro_approx.py
```

### Compare configurations across different parameter sets
```
python clean_code/selection.py clean_code/results_<tag1>/ clean_code/results_<tag2>/
```

## Key parameters (`clean_code/config.py`)

| Parameter | Value | Description |
|---|---|---|
| `T_AC` | 5 °C | Evaporator air outlet temperature |
| `delta_T_sh` | 5 K | Superheating |
| `delta_T_sc` | 7 K | Subcooling |
| `min_pinch_ev` | 5 K | Minimum evaporator pinch |
| `min_pinch_co` | 10 K | Minimum condenser pinch |
| `m_dot_vent_max` | 1.53 kg/s | Maximum fan mass flow |
| `delta_p_fan` | 265 Pa | Pressure drop across fan |
| `eta_fan` | 0.68 | Fan efficiency |
| `T_room_set` | 15 °C | Room temperature setpoint |
| `T_ON` | 16 °C | AC switch-on threshold |
| `T_OFF` | 10 °C | AC switch-off threshold |
| `t_min_runtime_s` | 300 s | Minimum compressor run time |
| `t_min_standstill_s` | 600 s | Minimum compressor standstill time |

## Variable parameters (swept in `main.py`)

- **Refrigerants**: R290, R1234yf, DME
- **Compressor bore diameters**: 30 mm, 40 mm, 50 mm
- **Seasons**: winter, spring, summer, fall (91 / 91 / 91 / 92 days)
