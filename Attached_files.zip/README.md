# Server Room Cooling — Simulation Code
**SHCT SS2026 Student Project — Bartha & Kellenberger**

## Requirements

```
pip install CoolProp numpy scipy pandas matplotlib
```

## File structure

```
├── Fluid_CP.py                   CoolProp wrapper for pure refrigerants (Roskosch)
├── Fluid_CP_moist_air.py         CoolProp wrapper for moist air (Roskosch)
├── compressor_model.py           Reciprocating compressor: volumetric & isentropic efficiency
├── verify_psychro_approx.py      Validates the bilinear h*(T,X) approximation vs CoolProp
│
├── ac_model/
│   ├── config.py                 AC-model parameters (refrigerant, compressor, pinch)
│   └── ac.py                     Refrigerant cycle states + NLP COP optimisation
│
└── clean_code/
    ├── config.py                 Central parameter file (all settings in one place)
    ├── performance_map.py        Build and query the precomputed COP/Q lookup tables
    ├── simulation.py             5-min on/off thermostat simulation (room ODE)
    ├── energy.py                 Daily energy balance and annual extrapolation
    ├── main.py                   Entry point: full sweep over all 9 configurations
    └── selection.py              Compare multiple result folders, generate comparison plot
```

## How to run

### 1. Build performance maps (once, ~2 min)
Edit `clean_code/main.py` and set `"build_map": True` in the TESTS list, then run:
```
python clean_code/main.py
```
Maps are saved to `clean_code/maps/` as `.pkl` files.

### 2. Run the simulation sweep
Set `"build_map": False, "sweep": True` and run again:
```
python clean_code/main.py
```
Results (CSV time series + ranking) are written to `clean_code/results_{tag}/`.

### 3. Validate the psychrometric approximation
```
python verify_psychro_approx.py
```

### 4. Compare configurations
```
python clean_code/selection.py clean_code/results_<tag1>/ clean_code/results_<tag2>/
```

## Key parameters (`clean_code/config.py`)

| Parameter | Value | Description |
|---|---|---|
| `T_AC` | 5 °C | Evaporator air outlet temperature |
| `m_dot_vent_max` | 1.5 kg/s | Maximum fan mass flow |
| `delta_p_fan` | 265 Pa | Pressure drop across fan |
| `eta_fan` | 0.68 | Fan efficiency |
| `T_room_set` | 15 °C | Room temperature setpoint |
| `T_ON` | 16 °C | AC switch-on threshold |
| `T_OFF` | 10 °C | AC switch-off threshold |
| `t_min_runtime_s` | 300 s | Minimum compressor run time |
| `t_min_standstill_s` | 600 s | Minimum compressor standstill time |

## Variable parameters (swept in `main.py`)

- **Refrigerants**: R290, R1234yf, DME  
- **Compressor bore diameters**: 30 mm, 40 mm, 50 mm  
- **Seasons**: winter, spring, summer, fall (91 / 91 / 91 / 92 days)
