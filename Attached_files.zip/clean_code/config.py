"""
Centralised configuration — all parameters in one place.
"""
import sys, os
_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import numpy as np
import Fluid_CP_moist_air as Fmoist

# ── Refrigerant cycle ─────────────────────────────────────────────────────────
T_AC           = 5.0    # °C  — evaporator air outlet temperature
delta_T_sh     = 5.0    # K   — superheating
delta_T_sc     = 7.0    # K   — subcooling
min_pinch_ev   = 5.0    # K   — minimum evaporator pinch
min_pinch_co   = 10.0   # K   — minimum condenser pinch
min_pressure_ratio = 2.0

# ── Compressor ────────────────────────────────────────────────────────────────
refrigerants            = ["R290", "R1234yf", "DME"]
compressor_diameters_mm = [30., 40., 50.]
Eh                      = "CBar"
fluid_so                = "air"
fluid_si                = "air"

# ── Fan (evaporator side) ─────────────────────────────────────────────────────
m_dot_vent_max = 1.53   # kg/s — maximum fan mass flow rate
delta_p_fan    = 265.   # Pa   — pressure drop across fan
eta_fan        = 0.68   # —    — fan efficiency
rho_air        = 1.2    # kg/m³

# ── Room ──────────────────────────────────────────────────────────────────────
V_air      = 3 * 6 * 10        # m³  (3 m × 6 m × 10 m)
T_room_set = 15.0   # °C  — temperature setpoint
VENT_GAIN  = 1.1    # —   — proportional gain above setpoint (1.0 below)

# Asymmetric hysteresis: switch on early, switch off late.
# T_ON close to setpoint → compressor starts immediately when room overheats,
#   preventing large temperature spikes at peak load.
# T_OFF well below setpoint → compressor cools the room deeply before stopping,
#   maximising thermal buffer capacity for the next load peak.
T_HYST_ON  = 1.0               # K   — switch-on hysteresis (narrow)
T_HYST_OFF = 5.0               # K   — switch-off hysteresis (wide)
T_ON       = T_room_set + T_HYST_ON   # 16°C — switch-on threshold
T_OFF      = T_room_set - T_HYST_OFF  # 10°C — switch-off threshold
phi_vent   = 0.6                # —   — design relative humidity of outdoor air

# ── Thermostat minimum run/standstill times ───────────────────────────────────
t_min_runtime_s    =  5 * 60   # s — minimum compressor run time
t_min_standstill_s = 10 * 60   # s — minimum compressor standstill time

# ── Room air mass and initial state ──────────────────────────────────────────
_T0   = T_room_set
_phi0 = 0.6
m_da = V_air / Fmoist.state_moist(["T", "phi"], [_T0, _phi0])["v*"]   # kg dry air

_X0 = Fmoist.state_moist(["T", "phi"], [_T0, _phi0])["X"]
X_0 = _X0                                                              # kg_w/kg_da
h_0 = Fmoist.state_moist(["T", "X"],  [_T0, _X0])["h*"]

X_AC_sat = Fmoist.state_moist(["T", "phi"], [T_AC, 1.0])["X"]

# ── Psychrometric linearisation: h*(T,X) ≈ _CP_A·T + _H_A0 + X·(_L0 + _CP_W·T)
_h_a_5  = Fmoist.state_moist(["T", "X"], [5.0,  0.0])["h*"]
_h_a_20 = Fmoist.state_moist(["T", "X"], [20.0, 0.0])["h*"]
_CP_A   = (_h_a_20 - _h_a_5) / 15.0
_H_A0   = _h_a_5 - _CP_A * 5.0

_hw_5   = (Fmoist.state_moist(["T", "X"], [5.0,  0.002])["h*"] - _h_a_5)  / 0.002
_hw_20  = (Fmoist.state_moist(["T", "X"], [20.0, 0.002])["h*"] - _h_a_20) / 0.002
_CP_W   = (_hw_20 - _hw_5) / 15.0
_L0     = _hw_5 - _CP_W * 5.0

# ── Performance map grid ──────────────────────────────────────────────────────
T_amb_grid  = np.linspace(1.,  35., 9)    # [1, 5, 9, 13, 17, 21, 25, 29, 33, 35] °C
T_room_grid = np.linspace(10., 30., 6)    # [10, 14, 18, 22, 26, 30] °C

# ── Seasonal weights ──────────────────────────────────────────────────────────
SEASON_DAYS = {"winter": 91, "spring": 91, "summer": 91, "fall": 92}

season_col = {
    "summer": "Ambient_Temp_Summer_C",
    "spring": "Ambient_Temp_Spring_C",
    "fall":   "Ambient_Temp_Fall_C",
    "winter": "Ambient_Temp_Winter_C",
}

# ── Electricity cost and temperature bounds ───────────────────────────────────
ELECTRICITY_PRICE_CHF_KWH = 0.25   # CHF/kWh
T_ROOM_MIN = T_OFF   # 10°C
T_ROOM_MAX = T_ON    # 16°C

# Overload threshold: a power deficit (Q_max < q_server) is only flagged as an
# overload when T_room exceeds this value; below it the compressor simply runs
# at its limit until the load drops or ventilation takes over.
T_overload_min = 16.0  # °C

# ── Auto-tag from config values ───────────────────────────────────────────────
TAG = (
    f"{int(T_AC)}C"
    f"_sh{int(delta_T_sh)}"
    f"_pev{int(min_pinch_ev)}"
    f"_pco{int(min_pinch_co)}"
    f"_fan{round(m_dot_vent_max * 100)}"
)

# ── File paths ────────────────────────────────────────────────────────────────
_HERE    = os.path.dirname(os.path.abspath(__file__))
CSV_5MIN = os.path.join(_HERE, '..', 'daily_profiles_5min.csv')
MAP_DIR  = os.path.join(_HERE, 'maps')
