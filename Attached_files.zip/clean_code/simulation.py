"""
5-minute on/off thermostat simulation of the server room.

Physics:
  - ODE state z = [h*, X]    (specific moist-air enthalpy, humidity ratio)
  - Ventilation: when outdoor air is cooler than setpoint and mass flow suffices
  - AC: on/off thermostat with hysteresis and minimum run/standstill times
  - Compressor always runs at full map capacity Q_max (no throttling)
"""
import sys, os
_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import numpy as np
import pandas as pd
import Fluid_CP_moist_air as Fmoist

import clean_code.config as cfg
from clean_code.performance_map import query


# ── Helper functions ──────────────────────────────────────────────────────────

def _hhmm_to_hours(arr):
    out = np.empty(len(arr))
    for k, t in enumerate(arr):
        h, m = str(t).split(":")
        out[k] = int(h) + int(m) / 60.
    return out


def _vent_state(T_amb, phi=cfg.phi_vent):
    s = Fmoist.state_moist(["T", "phi"], [T_amb, phi])
    return s["h*"], s["X"]


# ── Analytical time steps ─────────────────────────────────────────────────────
#
# Both operating modes (AC on / ventilation) reduce to the same linear ODE:
#
#   dh*/dt = (q + ṁ·(h*_in − h*)) / m_da
#           =  A − B·h*                        with  B = ṁ/m_da
#                                                    A = (q + ṁ·h*_in)/m_da
#
#   dX/dt  = (ṁ/m_da)·(X_in − X)
#           =  C − B·X                          with  C = (ṁ/m_da)·X_in = B·X_in
#
# Equilibrium values (derivatives = 0):
#   h*_eq = A/B = q/ṁ + h*_in         ← room enthalpy at steady state
#   X_eq  = X_in                       ← humidity ratio at steady state
#
# Exact solution of the linear IVP (no discretisation error, no solver overhead):
#   h*(t) = h*_eq + (h*₀ − h*_eq) · exp(−B·t)
#   X(t)  = X_eq  + (X₀  − X_eq ) · exp(−B·t)
#
# Limiting case ṁ → 0 (no mass flow, e.g. AC off):
#   dh*/dt = q / m_da  →  h*(t) = h*₀ + (q/m_da)·t
#   dX/dt  = 0          →  X(t)  = X₀


def _step_with_flow(z, dt, q, m_dot, h_in, X_in):
    """
    Exact timestep with active mass flow ṁ (AC or ventilation mode).

    Solves dh*/dt = A − B·h* and dX/dt = C − B·X analytically over interval dt.
    """
    h0, X0 = z
    if m_dot < 1e-12:
        # ṁ ≈ 0: limit case reduces to pure heating (= _step_no_flow)
        return [h0 + q / cfg.m_da * dt, X0]

    B     = m_dot / cfg.m_da          # decay rate [1/s]: inverse thermal time constant
    h_eq  = q / m_dot + h_in          # steady-state enthalpy: heat input q exactly
                                       #   balanced by supply air (h_in) when h_room = h_eq
    X_eq  = X_in                       # steady-state humidity: room X = supply X

    e = np.exp(-B * dt)                # damping factor for this timestep
    return [h_eq + (h0 - h_eq) * e,
            X_eq + (X0 - X_eq) * e]


def _step_no_flow(z, dt, q):
    """
    Exact timestep without mass flow (AC off, no ventilation): linear heating.

    dh*/dt = q/m_da is constant → trivial integration.
    dX/dt = 0 → humidity ratio remains constant.
    """
    return [z[0] + q / cfg.m_da * dt, z[1]]


# ── Main simulation ───────────────────────────────────────────────────────────

def simulate(season, refrigerant, c_d_mm, maps,
             T_AC=None, csv_path=None,
             t_min_on=cfg.t_min_runtime_s,
             t_min_off=cfg.t_min_standstill_s):
    """
    5-minute on/off thermostat simulation for one representative day.

    Parameters
    ----------
    season      : "winter" | "spring" | "summer" | "fall"
    refrigerant : "R290" | "R1234yf" | "DME"
    c_d_mm      : compressor bore diameter [mm]
    maps        : loaded performance maps (load_maps())
    T_AC        : evaporator air outlet temperature [°C], default cfg.T_AC
    csv_path    : path to 5-minute profile CSV, default cfg.CSV_5MIN

    Returns
    -------
    pd.DataFrame with columns:
        time, T_amb, q_server_kW, T_room, phi_room, X_room,
        vent_on, ac_on, m_dot_vent, Q_AC_kW, Q_AC_max_kW,
        m_dot_ac, W_comp_kW, fan_limited, ac_overloaded, n_cycles_cum
    """
    T_AC_    = T_AC     if T_AC     is not None else cfg.T_AC
    csv_path = csv_path if csv_path is not None else cfg.CSV_5MIN

    df_in    = pd.read_csv(csv_path)
    T_amb    = df_in[cfg.season_col[season]].values
    q_server = df_in["Server_Heating_Power_kW"].values
    time     = _hhmm_to_hours(df_in["Time"].values)
    n        = len(T_amb)
    dt       = float(time[1] - time[0]) * 3600.     # h → s

    X_AC_sat = Fmoist.state_moist(["T", "phi"], [T_AC_, 1.0])["X"]

    # Output arrays
    T_room_arr     = np.zeros(n)
    phi_room_arr   = np.zeros(n)
    X_room_arr     = np.zeros(n)
    vent_on_arr    = np.zeros(n, dtype=bool)
    ac_on_arr      = np.zeros(n, dtype=bool)
    m_dot_vent_arr = np.zeros(n)
    Q_AC_arr       = np.zeros(n)
    Q_AC_max_arr   = np.zeros(n)
    m_dot_ac_arr   = np.zeros(n)
    W_comp_arr     = np.zeros(n)   # compressor power after on/off degradation [kW]
    W_fan_arr      = np.zeros(n)   # fan power [kW]
    COP_eff_arr    = np.full(n, np.nan)  # system COP from map (full-load reference)
    fan_lim_arr    = np.zeros(n, dtype=bool)
    overload_arr   = np.zeros(n, dtype=bool)
    n_cycles_arr   = np.zeros(n, dtype=int)

    # State
    z          = [cfg.h_0, cfg.X_0]
    ac_therm   = False
    t_in_state = 0.0
    n_cycles   = 0
    q_est      = 3.0   # kW — initial heat load estimate (typical base load)

    for i in range(n):
        h_vent, X_vent = _vent_state(T_amb[i])

        # ── Record state before the step (physically correct assignment) ───────
        # T_room[i] is the temperature that triggers the thermostat decision for
        # step i; ac_on[i] / Q_AC[i] are the response to that state.
        z             = [z[0], max(float(z[1]), 0.0)]
        X_room        = z[1]
        X_room_arr[i] = X_room
        T_prev        = ((z[0] - cfg._H_A0 - X_room * cfg._L0)
                         / (cfg._CP_A + X_room * cfg._CP_W))
        T_room_arr[i] = T_prev
        if 0.0 < T_prev < 60.0:
            phi_room_arr[i] = Fmoist.state_moist(["T", "X"], [T_prev, X_room])["phi"]
        else:
            phi_room_arr[i] = float("nan")

        # ── Heat load estimate from observed temperature rise ─────────────────
        # Derived during fully uncooled timesteps (neither fan nor compressor
        # active in the previous step) — no knowledge of q_server required.
        if i > 0 and not vent_on_arr[i-1] and not ac_on_arr[i-1]:
            cp_eff_est = cfg._CP_A + X_room * cfg._CP_W
            q_raw = cfg.m_da * cp_eff_est * (T_prev - T_room_arr[i-1]) / dt
            q_est = max(q_raw, 0.0)

        # ── Check ventilation mode ────────────────────────────────────────────
        cp_eff        = cfg._CP_A + X_vent * cfg._CP_W
        T_vent_target = cfg.T_room_set - q_est / (cfg.m_dot_vent_max * cp_eff)
        dT_drive      = T_prev - T_amb[i]
        dT_error      = T_prev - T_vent_target
        active_gain   = cfg.VENT_GAIN if T_prev > cfg.T_room_set else 1.0
        m_dot_raw     = (cfg.m_dot_vent_max * active_gain * dT_error / dT_drive
                         if dT_drive > 1e-6 else cfg.m_dot_vent_max)
        m_dot_prop    = min(cfg.m_dot_vent_max, m_dot_raw)
        if T_amb[i] < cfg.T_room_set and dT_error > 0.0 and m_dot_raw < cfg.m_dot_vent_max:
            z = _step_with_flow(z, dt, q_server[i], m_dot_prop, h_vent, X_vent)
            vent_on_arr[i]    = True
            m_dot_vent_arr[i] = m_dot_prop
            rho_vent          = 1.0 / Fmoist.state_moist(["T", "phi"], [T_amb[i], cfg.phi_vent])["v*"]
            W_fan_arr[i]      = m_dot_prop * cfg.delta_p_fan / (rho_vent * cfg.eta_fan) / 1000.0
            COP_eff_arr[i]    = q_server[i] / W_fan_arr[i] if W_fan_arr[i] > 1e-9 else np.nan
            t_in_state += dt

        else:
            # ── AC thermostat mode ────────────────────────────────────────────
            # query() returns: (COP_eff, Q_cool_max, W_comp, W_fan)
            #   COP_eff    = Q_cool_max / (W_comp + W_fan)  — system incl. fan (from map)
            #   Q_cool_max = min(Q_cycle, ṁ_max·Δh_fan)    — fan-limited capacity [kW]
            #   W_comp     = ṁ_ref·(h2−h1)                 — compressor shaft power [kW]
            #   W_fan      = ṁ_fan·Δp/(ρ·η)               — fan power at rated point [kW]
            _cop_eff_rated, Q_max, W_comp_rated, W_fan_rated = query(
                maps, refrigerant, c_d_mm, T_amb[i], T_prev)
            Q_AC_max_arr[i] = Q_max

            vent_was_on = vent_on_arr[i - 1] if i > 0 else False

            prev_therm = ac_therm
            if ac_therm:
                if T_prev <= cfg.T_OFF and t_in_state >= t_min_on:
                    ac_therm, t_in_state = False, 0.0
            else:
                from_vent = vent_was_on and t_in_state >= t_min_off
                from_temp = T_prev >= cfg.T_ON and t_in_state >= t_min_off
                if from_vent or from_temp:
                    ac_therm, t_in_state = True, 0.0

            if ac_therm and not prev_therm:
                n_cycles += 1

            t_in_state += dt
            ac_on_arr[i] = ac_therm

            if ac_therm:
                X_AC   = X_AC_sat if X_room > X_AC_sat else X_room
                h_AC   = cfg._CP_A*T_AC_ + cfg._H_A0 + X_AC*(cfg._L0 + cfg._CP_W*T_AC_)
                h_room = z[0]
                dh     = max(h_room - h_AC, 0.0)

                m_dot_ideal = Q_max / dh if dh > 1e-6 else 0.0
                m_dot_ac    = min(m_dot_ideal, cfg.m_dot_vent_max)
                Q_delivered = m_dot_ac * dh

                # ── On/off cycling loss ────────────────────────────────────────
                # Compressor always runs at full capacity Q_cool_max and cycles
                # on/off. Part-load ratio r = heat load / full-load capacity.
                # COP_result = COP_inner · r/(0.9r+0.1)
                #   → at r=1: no loss; at r→0: COP→0 (pure start-up losses)
                # Rearranged: W_comp_cyc = W_comp_rated / cop_factor > W_comp_rated
                r          = min(q_server[i] / Q_delivered, 1.0) if Q_delivered > 1e-6 else 1.0
                cop_factor = r / (0.9 * r + 0.1)
                W_comp_cyc = W_comp_rated / cop_factor if cop_factor > 1e-9 else W_comp_rated

                fan_lim_arr[i]  = m_dot_ac < m_dot_ideal - 1e-9
                Q_AC_arr[i]     = Q_delivered
                m_dot_ac_arr[i] = m_dot_ac
                W_comp_arr[i]   = W_comp_cyc
                W_fan_arr[i]    = W_fan_rated
                COP_eff_arr[i]  = _cop_eff_rated       # full-load reference COP from map
                # Overload only relevant when room is too warm (T_prev > T_overload_min).
                # If room is already below threshold a capacity deficit is acceptable.
                overload_arr[i] = (q_server[i] > Q_max) and (T_prev > cfg.T_overload_min)

                z = _step_with_flow(z, dt, q_server[i], m_dot_ac, h_AC, X_AC)
            else:
                z = _step_no_flow(z, dt, q_server[i])

        n_cycles_arr[i] = n_cycles

    df = pd.DataFrame({
        "time":          time,
        "T_amb":         T_amb,
        "q_server_kW":   q_server,
        "T_room":        T_room_arr,
        "phi_room":      phi_room_arr,
        "X_room":        X_room_arr,
        "vent_on":       vent_on_arr,
        "ac_on":         ac_on_arr,
        "m_dot_vent":    m_dot_vent_arr,
        "Q_AC_kW":       Q_AC_arr,
        "Q_AC_max_kW":   Q_AC_max_arr,
        "m_dot_ac":      m_dot_ac_arr,
        # Electrical power breakdown:
        #   W_comp_kW  = compressor power after on/off degradation  [kW]
        #   W_fan_kW   = fan power                                   [kW]
        #   W_el_kW    = total electrical power                      [kW]
        "W_comp_kW":     W_comp_arr,
        "W_fan_kW":      W_fan_arr,
        "W_el_kW":       W_comp_arr + W_fan_arr,
        "COP_eff":       COP_eff_arr,   # full-load system COP from map (incl. fan)
        "fan_limited":   fan_lim_arr,
        "ac_overloaded": overload_arr,
        "n_cycles_cum":  n_cycles_arr,
    })
    return df
